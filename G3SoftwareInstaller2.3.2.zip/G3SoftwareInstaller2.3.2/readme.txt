run GlobalSetup.exe to install software
